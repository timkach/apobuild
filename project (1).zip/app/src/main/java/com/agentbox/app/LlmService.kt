package com.agentbox.app

import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import android.os.Process
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import org.json.JSONArray
import java.util.concurrent.Executors

const val MSG_GEN = 1
const val MSG_KILL = 2
const val MSG_OK = 10
const val MSG_ERR = 11

interface LocalEngine {
    fun generate(system: String, msgsJson: String, prompt: String): String
    fun close()
}

class MediaPipeEngine(ctx: Context, path: String, maxTokens: Int, gpu: Boolean) : LocalEngine {
    private val llm: LlmInference = LlmInference.createFromOptions(
        ctx,
        LlmInference.LlmInferenceOptions.builder()
            .setModelPath(path)
            .setMaxTokens(maxTokens)
            .setPreferredBackend(if (gpu) LlmInference.Backend.GPU else LlmInference.Backend.CPU)
            .build(),
    )
    override fun generate(system: String, msgsJson: String, prompt: String): String = llm.generateResponse(prompt)
    override fun close() { llm.close() }
}

class LiteRtEngine(ctx: Context, path: String, gpu: Boolean) : LocalEngine {
    private val engine: Engine = Engine(
        EngineConfig(
            modelPath = path,
            backend = if (gpu) Backend.GPU() else Backend.CPU(),
            cacheDir = ctx.cacheDir.path,
        ),
    ).also { it.initialize() }

    override fun generate(system: String, msgsJson: String, prompt: String): String {
        val arr = JSONArray(msgsJson)
        val turns = (0 until arr.length()).map { arr.getJSONObject(it) }.filter { it.getString("role") != "system" }
        val last = turns.lastOrNull()?.getString("content") ?: ""
        val before = turns.dropLast(1)
        // Conversation хранит историю сам, поэтому прошлые реплики отдаём одним текстом
        val text = if (before.isEmpty()) last else buildString {
            append("Conversation so far:\n")
            before.forEach {
                append(if (it.getString("role") == "assistant") "ASSISTANT: " else "USER: ")
                append(it.getString("content")).append("\n\n")
            }
            append("Continue as ASSISTANT. Latest USER message:\n").append(last)
        }
        val cfg = ConversationConfig(systemInstruction = Contents.of(system))
        return engine.createConversation(cfg).use { it.sendMessage(text).toString() }
    }

    override fun close() { engine.close() }
}

class LlmService : Service() {
    private val worker = Executors.newSingleThreadExecutor()
    private var eng: LocalEngine? = null
    private var key = ""

    private val handler = Handler(Looper.getMainLooper()) { m ->
        when (m.what) {
            MSG_KILL -> {
                AppLog.info("LLM", "процесс модели остановлен по запросу")
                Process.killProcess(Process.myPid())
            }
            MSG_GEN -> {
                val data = Bundle(m.data)
                val replyTo = m.replyTo
                val id = m.arg1
                worker.execute { process(id, data, replyTo) }
            }
        }
        true
    }
    private val messenger = Messenger(handler)

    override fun onBind(intent: Intent?): IBinder = messenger.binder

    private fun process(id: Int, d: Bundle, replyTo: Messenger?) {
        val reply = Message.obtain(null, MSG_OK, id, 0)
        try {
            val engine = d.getString("engine") ?: "mediapipe"
            val path = d.getString("path") ?: error("нет пути к модели")
            val maxTokens = d.getInt("maxTokens", 1280)
            val gpu = d.getBoolean("gpu")
            val k = "$engine|$path|$maxTokens|$gpu"
            if (k != key || eng == null) {
                try { eng?.close() } catch (_: Throwable) {}
                eng = null
                AppLog.info("LLM", "загрузка модели: $k")
                val t0 = System.currentTimeMillis()
                eng = if (engine == "litertlm") LiteRtEngine(applicationContext, path, gpu)
                else MediaPipeEngine(applicationContext, path, maxTokens, gpu)
                key = k
                AppLog.info("LLM", "модель загружена за ${(System.currentTimeMillis() - t0) / 1000} с")
            }
            val t1 = System.currentTimeMillis()
            val text = eng!!.generate(d.getString("system") ?: "", d.getString("msgs") ?: "[]", d.getString("prompt") ?: "")
            AppLog.info("LLM", "ответ ${text.length} симв. за ${(System.currentTimeMillis() - t1) / 1000} с")
            reply.data = Bundle().apply { putString("text", text) }
        } catch (t: Throwable) {
            AppLog.error("LLM", "ошибка генерации", t)
            reply.what = MSG_ERR
            reply.data = Bundle().apply { putString("error", "${t.javaClass.simpleName}: ${t.message}") }
        }
        try { replyTo?.send(reply) } catch (t: Throwable) { AppLog.error("LLM", "не удалось отправить ответ", t) }
    }
}
