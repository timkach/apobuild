package com.agentbox.app

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        AppLog.info("UI", "onCreate")
        setContent { App() }
    }
}

@Composable
fun App(vm: AgentVM = viewModel()) {
    var page by remember { mutableStateOf("chat") }
    var crash by remember { mutableStateOf(AppLog.takeCrash()) }
    BackHandler(page != "chat") { page = if (page == "adv" || page == "logs") "settings" else "chat" }
    AgentTheme(vm.s.themeAccent, vm.s.themeMode) {
        Surface(Modifier.fillMaxSize()) {
            when (page) {
                "chat" -> ChatScreen(vm, { page = "settings" }, { page = "logs" })
                "settings" -> SettingsScreen(vm, { page = "chat" }, { page = "adv" }, { page = "logs" })
                "adv" -> AdvancedScreen(vm) { page = "settings" }
                else -> LogsScreen { page = "settings" }
            }
        }
        crash?.let { c ->
            AlertDialog(
                onDismissRequest = { crash = null },
                title = { Text("Прошлый запуск упал") },
                text = { SelectionContainer { Text(c.take(700), fontFamily = FontFamily.Monospace, fontSize = 11.sp) } },
                confirmButton = { TextButton(onClick = { crash = null; page = "logs" }) { Text("Открыть логи") } },
                dismissButton = { TextButton(onClick = { crash = null }) { Text("Закрыть") } },
            )
        }
    }
}

@Composable
fun ChatScreen(vm: AgentVM, openSettings: () -> Unit, openLogs: () -> Unit) {
    var input by remember { mutableStateOf("") }
    val list = rememberLazyListState()
    LaunchedEffect(vm.messages.size, vm.messages.lastOrNull()?.text) {
        if (vm.messages.isNotEmpty()) list.animateScrollToItem(vm.messages.lastIndex)
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("AgentBox", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            TBtn(if (vm.s.mode == "local") "🧠 Локал." else "☁ API") { vm.s.mode = if (vm.s.mode == "local") "api" else "local" }
            TBtn("📜") { openLogs() }
            TBtn("🗑") { vm.newChat() }
            TBtn("⚙") { openSettings() }
        }
        if (vm.running) LinearProgressIndicator(Modifier.fillMaxWidth()) else HorizontalDivider()
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp), state = list, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (vm.messages.isEmpty()) item {
                Text(
                    "Опиши задачу: агент сам выполняет команды (${if (vm.s.runtime == "android") "Android shell" else "Linux ${vm.s.distro}"}) и отчитывается.\n" +
                        "Кнопка ⌨ слева от поля включает ручной ввод команд.\nПеред первым запуском настрой модель и среду в ⚙.",
                    Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            items(vm.messages) { Bubble(it) }
        }
        HorizontalDivider()
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.Bottom) {
            FilledTonalIconToggleButton(checked = vm.manual, onCheckedChange = { vm.manual = it }) { Text(if (vm.manual) "$" else "⌨") }
            Spacer(Modifier.width(6.dp))
            OutlinedTextField(
                input, { input = it }, Modifier.weight(1f),
                placeholder = { Text(if (vm.manual) "Команда для выполнения…" else "Задача для агента…") }, maxLines = 5,
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = {
                if (vm.running) vm.stop() else if (input.isNotBlank()) { vm.send(input.trim()); input = "" }
            }) { Text(if (vm.running) "■" else "➤") }
        }
    }
    vm.pendingCmd?.let { cmd ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Выполнить команду?") },
            text = { SelectionContainer { Text(cmd, fontFamily = FontFamily.Monospace, fontSize = 13.sp) } },
            confirmButton = { TextButton(onClick = { vm.answer(true) }) { Text("Выполнить") } },
            dismissButton = { TextButton(onClick = { vm.answer(false) }) { Text("Отклонить") } },
        )
    }
}

@Composable
fun Bubble(m: UiMsg) {
    val cs = MaterialTheme.colorScheme
    val bg = when (m.kind) {
        "user" -> cs.primaryContainer
        "cmd" -> cs.tertiaryContainer
        "out" -> cs.surfaceVariant
        "sys" -> cs.errorContainer
        else -> cs.secondaryContainer
    }
    val mono = m.kind == "cmd" || m.kind == "out"
    val text = when (m.kind) { "cmd" -> "$ ${m.text}"; "out" -> m.text.take(3000); else -> m.text }
    Box(Modifier.fillMaxWidth(), contentAlignment = if (m.kind == "user") Alignment.CenterEnd else Alignment.CenterStart) {
        Surface(color = bg, shape = RoundedCornerShape(12.dp), modifier = Modifier.widthIn(max = 340.dp)) {
            SelectionContainer {
                Text(text, Modifier.padding(10.dp), fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default, fontSize = if (mono) 12.sp else 15.sp)
            }
        }
    }
}
