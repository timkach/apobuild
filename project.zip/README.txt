AgentBox — Android-агент: локальный ИИ (MediaPipe) / API + Linux через proot.
Сборка: см. .github/workflows/build.yml (положи project.zip в корень репозитория).
libproot.so скачивается workflow-ом при сборке в app/src/main/jniLibs/arm64-v8a/.
