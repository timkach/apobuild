package com.agentbox.app

data class UiMsg(val kind: String, val text: String)   // user | assistant | cmd | out | sys

class Agent(
    private val llm: Llm,
    private val maxSteps: Int,
    private val charBudget: Int,
    private val exec: suspend (String) -> String,
    private val confirm: suspend (String) -> Boolean,
) {
    private val cmdRe = Regex("```(?:bash|sh|shell)[ \\t]*\\r?\\n(.*?)```", RegexOption.DOT_MATCHES_ALL)

    suspend fun run(history: MutableList<Msg>, emit: (String, String) -> Unit) {
        repeat(maxSteps) {
            val reply = llm.chat(trim(history)).trim()
            history += Msg("assistant", reply)
            val cmd = cmdRe.find(reply)?.groupValues?.get(1)?.trim()
            if (cmd.isNullOrEmpty()) { emit("assistant", reply); return }
            val before = reply.substringBefore("```").trim()
            if (before.isNotEmpty()) emit("assistant", before)
            emit("cmd", cmd)
            val out = if (confirm(cmd)) exec(cmd) else "[пользователь отклонил команду]"
            emit("out", out)
            history += Msg("user", "OUTPUT:\n$out")
        }
        emit("sys", "Достигнут лимит шагов ($maxSteps). Напиши «продолжай», чтобы идти дальше.")
    }

    /** Режем старую историю, чтобы влезть в контекст локальной модели. */
    private fun trim(h: List<Msg>): List<Msg> {
        val l = h.toMutableList()
        while (l.size > 3 && l.sumOf { it.content.length } > charBudget) {
            l.removeAt(1)
            if (l.size > 2) l.removeAt(1)
        }
        return l
    }
}
