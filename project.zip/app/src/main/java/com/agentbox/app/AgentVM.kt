package com.agentbox.app

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.io.File

class AgentVM(private val app: Application) : AndroidViewModel(app) {
    val s = Settings(app)
    val linux = LinuxManager(app)
    val models = ModelManager(app)

    val messages = mutableStateListOf<UiMsg>()
    val modelList = mutableStateListOf<String>()
    var running by mutableStateOf(false); private set
    var pendingCmd by mutableStateOf<String?>(null); private set
    var linuxStatus by mutableStateOf("")
    var modelStatus by mutableStateOf("")
    private var tick by mutableStateOf(0)

    private val history = mutableListOf<Msg>()
    private var job: Job? = null
    private var pending: CompletableDeferred<Boolean>? = null

    init { refreshModels() }

    fun isInstalled(id: String): Boolean { tick; return linux.installed(id) }
    fun refreshModels() { modelList.clear(); modelList.addAll(models.list()) }

    private fun sysPrompt(): String {
        val d = DISTROS.first { it.id == s.distro }
        return s.systemPrompt.replace("{distro}", d.title).replace("{pkg}", d.pkgHint)
    }

    private fun buildLlm(): Llm {
        if (s.mode == "api") {
            require(s.apiUrl.isNotBlank()) { "Укажи API URL в настройках" }
            return ApiLlm(s.apiUrl, s.apiKey, s.apiModel, s.temperature.toDoubleOrNull() ?: 0.4)
        }
        val f = File(models.dir, s.localModel)
        require(s.localModel.isNotBlank() && f.exists()) { "Выбери или загрузи модель .task в настройках" }
        return LlmCache.get(app, f.path, s.maxTokensI, s.gpu, s.template)
    }

    private suspend fun runCmd(cmd: String): String = try {
        when {
            !linux.prootBin.exists() -> "[error] libproot.so не найден в APK"
            !linux.installed(s.distro) -> "[error] Linux (${s.distro}) не установлен. Попроси пользователя установить его в настройках."
            else -> linux.exec(s.distro, cmd, s.timeoutI, s.bindStorage, s.maxOutI)
        }
    } catch (e: CancellationException) { throw e } catch (e: Throwable) { "[error] ${e.message}" }

    private suspend fun confirm(cmd: String): Boolean {
        if (!s.confirm) return true
        val d = CompletableDeferred<Boolean>()
        pending = d; pendingCmd = cmd
        return try { d.await() } finally { pendingCmd = null; pending = null }
    }

    fun answer(ok: Boolean) { pending?.complete(ok) }

    fun send(text: String) {
        if (running) return
        messages += UiMsg("user", text)
        val sys = Msg("system", sysPrompt())
        if (history.isEmpty()) history += sys else history[0] = sys
        history += Msg("user", text)
        job = viewModelScope.launch {
            running = true
            try {
                val llm = buildLlm()
                val budget = if (s.mode == "api") 400_000 else (s.maxTokensI * 3 * 0.6).toInt()
                Agent(llm, s.maxStepsI, budget, ::runCmd, ::confirm).run(history) { k, t -> messages += UiMsg(k, t) }
            } catch (e: CancellationException) {
                messages += UiMsg("sys", "Остановлено"); throw e
            } catch (e: Throwable) {
                messages += UiMsg("sys", "Ошибка: ${e.message}")
            } finally { running = false }
        }
    }

    fun stop() { pending?.complete(false); job?.cancel() }
    fun newChat() { stop(); messages.clear(); history.clear() }

    fun installDistro(id: String) {
        viewModelScope.launch {
            try {
                linux.install(DISTROS.first { it.id == id }) { linuxStatus = it }
                linuxStatus = "Установлено ✔"
            } catch (e: Throwable) { linuxStatus = "Ошибка: ${e.message}" }
            tick++
        }
    }

    fun deleteDistro(id: String) { linux.delete(id); linuxStatus = ""; tick++ }

    fun downloadModel() {
        viewModelScope.launch {
            try {
                val n = models.download(s.modelUrl, s.hfToken) { modelStatus = it }
                s.localModel = n; modelStatus = "Готово: $n ✔"
            } catch (e: Throwable) { modelStatus = "Ошибка: ${e.message}" }
            refreshModels()
        }
    }

    fun importModel(uri: Uri) {
        viewModelScope.launch {
            try {
                val n = models.import(uri) { modelStatus = it }
                s.localModel = n; modelStatus = "Готово: $n ✔"
            } catch (e: Throwable) { modelStatus = "Ошибка: ${e.message}" }
            refreshModels()
        }
    }

    fun deleteModel(name: String) {
        models.delete(name)
        if (s.localModel == name) s.localModel = ""
        refreshModels()
    }
}
