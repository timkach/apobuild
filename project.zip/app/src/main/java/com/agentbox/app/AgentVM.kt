package com.agentbox.app

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.io.File

class AgentVM(private val app: Application) : AndroidViewModel(app) {
    val s = Settings(app)
    val linux = LinuxManager(app)
    val models = ModelManager(app)

    val messages = mutableStateListOf<UiMsg>()
    val modelList = mutableStateListOf<String>()
    var running by mutableStateOf(false); private set
    var pendingCmd by mutableStateOf<String?>(null); private set
    var manual by mutableStateOf(false)
    var linuxStatus by mutableStateOf("")
    var modelStatus by mutableStateOf("")
    var diag by mutableStateOf("")
    private var tick by mutableStateOf(0)

    private val history = mutableListOf<Msg>()
    private var job: Job? = null
    private var pending: CompletableDeferred<Boolean>? = null

    private val handler = CoroutineExceptionHandler { _, t ->
        AppLog.error("VM", "необработанная ошибка корутины", t)
        messages += UiMsg("sys", "Внутренняя ошибка: ${t.message}")
        running = false
    }

    init { refreshModels() }

    fun isInstalled(id: String): Boolean { tick; return linux.installed(id) }
    fun refreshModels() { modelList.clear(); modelList.addAll(models.list()) }

    private fun sysPrompt(): String {
        val (name, pkg) = if (s.runtime == "android") "Android shell (toybox, no root, no package manager)" to "none"
        else DISTROS.first { it.id == s.distro }.let { "${it.title} Linux (proot, root user)" to it.pkgHint }
        return s.systemPrompt.replace("{distro}", name).replace("{pkg}", pkg)
    }

    private fun buildLlm(): Llm {
        if (s.mode == "api") {
            require(s.apiUrl.isNotBlank()) { "Укажи API URL в настройках" }
            return ApiLlm(s.apiUrl, s.apiKey, s.apiModel, s.temperature.toDoubleOrNull() ?: 0.4)
        }
        val name = s.localModel
        val f = File(models.dir, name)
        require(name.isNotBlank() && f.exists()) { "Выбери или загрузи модель в настройках (Локальный ИИ)" }
        val engine = when {
            s.engine != "auto" -> s.engine
            name.endsWith(".litertlm") -> "litertlm"
            else -> "mediapipe"
        }
        check(!(engine == "mediapipe" && name.endsWith(".litertlm"))) { "Файл .litertlm открывается движком LiteRT-LM (Настройки → Движок)" }
        check(!(engine == "litertlm" && name.endsWith(".task"))) { "Файл .task открывается движком MediaPipe (Настройки → Движок)" }
        val all = s.templates()
        val tpl = all[s.template] ?: all.values.first()
        AppLog.info("VM", "локальная модель: $name, движок=$engine, шаблон=${s.template}, ctx=${s.maxTokensI}, gpu=${s.gpu}")
        return LocalLlm(app, engine, f.path, s.maxTokensI, s.gpu, tpl)
    }

    private suspend fun runCmd(cmd: String): String = try {
        when {
            s.runtime == "proot" && !linux.prootBin.exists() -> "[error] libproot.so не найден в APK"
            s.runtime == "proot" && !linux.installed(s.distro) ->
                "[error] Linux (${s.distro}) не установлен. Попроси пользователя установить его в настройках или переключить среду на Android shell."
            else -> linux.exec(s, cmd)
        }
    } catch (e: CancellationException) { throw e } catch (e: Throwable) {
        AppLog.error("EXEC", "ошибка запуска команды", e)
        "[error] ${e.javaClass.simpleName}: ${e.message}"
    }

    private suspend fun confirm(cmd: String): Boolean {
        if (!s.confirm) return true
        val d = CompletableDeferred<Boolean>()
        pending = d; pendingCmd = cmd
        return try { d.await() } finally { pendingCmd = null; pending = null }
    }

    fun answer(ok: Boolean) { pending?.complete(ok) }

    private fun ensureSystem() {
        val sys = Msg("system", sysPrompt())
        if (history.isEmpty()) history += sys else history[0] = sys
    }

    fun send(text: String) {
        if (running) return
        if (manual) { runManual(text); return }
        messages += UiMsg("user", text)
        ensureSystem()
        history += Msg("user", text)
        AppLog.info("VM", "новая задача: ${text.take(200)} (режим=${s.mode})")
        job = viewModelScope.launch(handler) {
            running = true
            try {
                val llm = buildLlm()
                val budget = if (s.mode == "api") 400_000 else (s.maxTokensI * 3 * 0.6).toInt()
                Agent(llm, s.maxStepsI, budget, s.cmdRegex(), ::runCmd, ::confirm).run(history) { k, t -> messages += UiMsg(k, t) }
            } catch (e: CancellationException) {
                messages += UiMsg("sys", "Остановлено"); throw e
            } catch (e: Throwable) {
                AppLog.error("VM", "ошибка агента", e)
                messages += UiMsg("sys", "Ошибка: ${e.message}")
            } finally { running = false }
        }
    }

    /** Ручной ввод команды: выполняется как есть, результат попадает и в историю агента. */
    fun runManual(cmd: String) {
        if (running) return
        messages += UiMsg("cmd", cmd)
        job = viewModelScope.launch(handler) {
            running = true
            try {
                val out = runCmd(cmd)
                messages += UiMsg("out", out)
                ensureSystem()
                history += Msg("user", "[пользователь сам выполнил команду]\n$ $cmd\n$out")
            } catch (e: CancellationException) { throw e } finally { running = false }
        }
    }

    fun stop() { pending?.complete(false); job?.cancel() }
    fun newChat() { stop(); messages.clear(); history.clear() }

    fun installDistro(id: String) {
        viewModelScope.launch(handler) {
            try {
                linux.install(DISTROS.first { it.id == id }) { linuxStatus = it }
                linuxStatus = "Установлено ✔"
            } catch (e: Throwable) { linuxStatus = "Ошибка: ${e.message}" }
            tick++
        }
    }

    fun deleteDistro(id: String) { linux.delete(id); linuxStatus = ""; tick++ }

    fun runDiag() {
        viewModelScope.launch(handler) {
            diag = "Выполняю…"
            diag = try { linux.diagnose(s) } catch (e: Throwable) { AppLog.error("DIAG", "сбой диагностики", e); "Ошибка: $e" }
        }
    }

    fun applyPreset(p: Preset) {
        s.template = p.template; s.modelUrl = p.url; s.maxTokens = p.maxTokens.toString()
        modelStatus = if (p.token) "Для этой модели нужен HF токен и принятая лицензия" else "Ссылка подставлена, нажми «Скачать по URL»"
    }

    fun downloadModel() {
        viewModelScope.launch(handler) {
            try {
                val n = models.download(s.modelUrl, s.hfToken) { modelStatus = it }
                s.localModel = n; modelStatus = "Готово: $n ✔"
            } catch (e: Throwable) { modelStatus = "Ошибка: ${e.message}" }
            refreshModels()
        }
    }

    fun importModel(uri: Uri) {
        viewModelScope.launch(handler) {
            try {
                val n = models.import(uri) { modelStatus = it }
                s.localModel = n; modelStatus = "Готово: $n ✔"
            } catch (e: Throwable) { modelStatus = "Ошибка: ${e.message}" }
            refreshModels()
        }
    }

    fun deleteModel(name: String) {
        models.delete(name)
        if (s.localModel == name) s.localModel = ""
        refreshModels()
    }
}
