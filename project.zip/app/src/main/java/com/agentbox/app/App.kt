package com.agentbox.app

import android.app.Application
import android.content.Context
import android.os.Build
import android.os.Looper
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        AppLog.init(this)
    }
}

/** Общий лог в файле: пишут оба процесса (основной и :llm), читает страница «Логи». */
object AppLog {
    private var file: File? = null
    private var crashFile: File? = null
    private var proc = "main"
    private var flag: File? = null
    @Volatile var composed = false
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    fun init(ctx: Context) {
        file = File(ctx.filesDir, "agentbox.log")
        crashFile = File(ctx.filesDir, "last_crash.txt")
        flag = File(ctx.filesDir, "launching.flag")
        proc = (if (Build.VERSION.SDK_INT >= 28) Application.getProcessName() else null)?.substringAfter(':', "main") ?: "main"
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, ex ->
            error("CRASH", "необработанное исключение в потоке ${t.name}", ex)
            val isMain = t == Looper.getMainLooper().thread
            if (isMain || proc != "main") {
                try { crashFile?.writeText("[$proc/${t.name}]\n" + android.util.Log.getStackTraceString(ex)) } catch (_: Throwable) {}
                prev?.uncaughtException(t, ex)
            }
            // сбой в фоновом потоке основного процесса: гасим, приложение продолжает работать
        }
        info("APP", "старт процесса $proc, Android ${Build.VERSION.SDK_INT}, ${Build.MANUFACTURER} ${Build.MODEL}")
    }

    @Synchronized
    private fun write(level: String, tag: String, msg: String) {
        val f = file ?: return
        try {
            if (f.length() > 1_500_000) f.writeText(f.readText().takeLast(300_000))
            FileOutputStream(f, true).use { it.write("${fmt.format(Date())} [$proc] $level $tag: $msg\n".toByteArray()) }
        } catch (_: Throwable) {}
    }

    fun info(tag: String, msg: String) = write("I", tag, msg)
    fun error(tag: String, msg: String, t: Throwable? = null) =
        write("E", tag, if (t != null) msg + "\n" + android.util.Log.getStackTraceString(t) else msg)

    fun read(maxChars: Int = 60_000): String = try { file?.readText()?.takeLast(maxChars) ?: "" } catch (_: Throwable) { "" }
    fun clear() { try { file?.writeText("") } catch (_: Throwable) {} }

    /** true, если прошлый запуск не дошёл до отрисовки интерфейса */
    fun lastLaunchFailed(): Boolean = flag?.exists() == true
    fun markLaunching() { composed = false; try { flag?.writeText("1") } catch (_: Throwable) {} }
    fun markLaunchOk() { if (!composed) { composed = true; info("UI", "интерфейс отрисован"); try { flag?.delete() } catch (_: Throwable) {} } }

    /** Текст краша прошлого запуска (показывается один раз). */
    fun takeCrash(): String? {
        val f = crashFile ?: return null
        if (!f.exists()) return null
        val t = try { f.readText() } catch (_: Throwable) { "" }
        f.delete()
        return t.ifBlank { null }
    }
}
