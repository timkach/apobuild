package com.agentbox.app

import android.content.Context
import android.system.Os
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runInterruptible
import kotlinx.coroutines.withContext
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

class LinuxManager(private val ctx: Context) {
    /** proot лежит как libproot.so в jniLibs, поэтому его можно запускать напрямую. */
    val prootBin: File get() = File(ctx.applicationInfo.nativeLibraryDir, "libproot.so")
    fun rootfs(id: String) = File(ctx.filesDir, "distros/$id")
    fun installed(id: String) = File(rootfs(id), ".installed").exists()

    suspend fun install(d: Distro, onStatus: (String) -> Unit) = withContext(Dispatchers.IO) {
        val dir = rootfs(d.id)
        dir.deleteRecursively(); dir.mkdirs()
        val tmp = File(ctx.cacheDir, "${d.id}.rootfs")
        try {
            onStatus("Скачивание ${d.title}…")
            Net.download(d.url, tmp, null) { done, total ->
                onStatus("Скачивание ${d.title}: ${done / 1_000_000} / ${if (total > 0) total / 1_000_000 else "?"} МБ")
            }
            extract(tmp, dir, d.url) { onStatus("Распаковка: $it файлов…") }
            File(dir, "root").mkdirs()
            File(dir, "tmp").mkdirs()
            File(dir, "etc/resolv.conf").apply { delete(); parentFile?.mkdirs(); writeText("nameserver 8.8.8.8\nnameserver 1.1.1.1\n") }
            File(dir, "etc/hosts").apply { delete(); writeText("127.0.0.1 localhost\n") }
            File(dir, ".installed").writeText("ok")
        } catch (e: Throwable) {
            dir.deleteRecursively(); throw e
        } finally {
            tmp.delete()
        }
    }

    fun delete(id: String) { rootfs(id).deleteRecursively() }

    private fun extract(src: File, dir: File, url: String, onCount: (Int) -> Unit) {
        val raw = BufferedInputStream(src.inputStream(), 256 * 1024)
        val dec = if (url.endsWith(".xz")) XZCompressorInputStream(raw) else GzipCompressorInputStream(raw)
        val root = dir.canonicalFile
        var n = 0
        TarArchiveInputStream(dec).use { tar ->
            while (true) {
                val e = tar.nextTarEntry ?: break
                val name = e.name.removePrefix("./")
                if (name.isEmpty() || name == ".") continue
                val out = File(root, name)
                if (!out.canonicalPath.startsWith(root.path) && !e.isSymbolicLink) continue
                when {
                    e.isDirectory -> { out.mkdirs(); chmod(out, e.mode or 0x1C0) }
                    e.isSymbolicLink -> {
                        out.parentFile?.mkdirs(); out.delete()
                        try { Os.symlink(e.linkName, out.path) } catch (_: Throwable) {}
                    }
                    e.isLink -> {
                        out.parentFile?.mkdirs(); out.delete()
                        val t = File(root, e.linkName.removePrefix("./"))
                        if (t.exists()) t.copyTo(out, true)
                    }
                    e.isFile -> {
                        out.parentFile?.mkdirs(); out.delete()
                        out.outputStream().use { tar.copyTo(it) }
                        chmod(out, e.mode or 0x180)
                    }
                    else -> {} // устройства/fifo пропускаем: /dev берём у Android
                }
                if (++n % 500 == 0) onCount(n)
            }
        }
    }

    private fun chmod(f: File, mode: Int) { try { Os.chmod(f.path, mode and 0xFFF) } catch (_: Throwable) {} }

    /** Запуск команды внутри rootfs через proot. */
    suspend fun exec(distro: String, cmd: String, timeoutSec: Long, bindStorage: Boolean, maxChars: Int): String =
        withContext(Dispatchers.IO) {
            val root = rootfs(distro)
            val args = mutableListOf(
                prootBin.path, "--link2symlink", "-0", "--kill-on-exit",
                "-r", root.path, "-b", "/dev", "-b", "/proc", "-b", "/sys",
            )
            if (bindStorage && File("/sdcard").exists()) { args += listOf("-b", "/sdcard:/sdcard") }
            args += listOf(
                "-w", "/root", "/usr/bin/env", "-i",
                "HOME=/root", "USER=root", "TERM=xterm", "LANG=C.UTF-8", "DEBIAN_FRONTEND=noninteractive",
                "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
                "/bin/sh", "-c", cmd,
            )
            val pb = ProcessBuilder(args).redirectErrorStream(true)
            pb.environment()["PROOT_TMP_DIR"] = ctx.cacheDir.path
            pb.environment()["PROOT_NO_SECCOMP"] = "1"
            val proc = pb.start()
            val sb = StringBuilder()
            val reader = thread(isDaemon = true) {
                try {
                    proc.inputStream.bufferedReader().use { r ->
                        val buf = CharArray(4096)
                        while (true) {
                            val k = r.read(buf)
                            if (k < 0) break
                            synchronized(sb) { if (sb.length < maxChars * 8) sb.append(buf, 0, k) }
                        }
                    }
                } catch (_: Throwable) {}
            }
            try {
                val finished = runInterruptible { proc.waitFor(timeoutSec, TimeUnit.SECONDS) }
                if (!finished) proc.destroyForcibly()
                reader.join(2000)
                var text = synchronized(sb) { sb.toString() }
                if (text.length > maxChars) text = "…(обрезано)\n" + text.takeLast(maxChars)
                val tail = if (finished) "[exit ${proc.exitValue()}]" else "[таймаут ${timeoutSec}с, процесс убит]"
                if (text.isBlank()) tail else text.trimEnd() + "\n" + tail
            } finally {
                if (proc.isAlive) proc.destroyForcibly()
            }
        }
}
