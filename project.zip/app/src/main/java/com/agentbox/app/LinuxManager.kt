package com.agentbox.app

import android.content.Context
import android.os.Build
import android.system.Os
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runInterruptible
import kotlinx.coroutines.withContext
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

class LinuxManager(private val ctx: Context) {
    private val nativeDir: String get() = ctx.applicationInfo.nativeLibraryDir
    val prootBin: File get() = File(nativeDir, "libproot.so")
    /** Если есть loader, значит proot взят из Termux (собран под Android). */
    val loaderBin: File get() = File(nativeDir, "libproot-loader.so")

    fun rootfs(id: String) = File(ctx.filesDir, "distros/$id")
    fun installed(id: String) = File(rootfs(id), ".installed").exists()

    // ---------------- установка дистрибутива ----------------

    suspend fun install(d: Distro, onStatus: (String) -> Unit) = withContext(Dispatchers.IO) {
        val dir = rootfs(d.id)
        dir.deleteRecursively(); dir.mkdirs()
        val tmp = File(ctx.cacheDir, "${d.id}.rootfs")
        try {
            AppLog.info("LINUX", "установка ${d.id} из ${d.url}")
            onStatus("Скачивание ${d.title}…")
            Net.download(d.url, tmp, null) { done, total ->
                onStatus("Скачивание ${d.title}: ${done / 1_000_000} / ${if (total > 0) total / 1_000_000 else "?"} МБ")
            }
            extract(tmp, dir, d.url) { onStatus("Распаковка: $it файлов…") }
            File(dir, "root").mkdirs()
            File(dir, "tmp").mkdirs()
            File(dir, "etc/resolv.conf").apply { delete(); parentFile?.mkdirs(); writeText("nameserver 8.8.8.8\nnameserver 1.1.1.1\n") }
            File(dir, "etc/hosts").apply { delete(); writeText("127.0.0.1 localhost\n") }
            File(dir, ".installed").writeText("ok")
            AppLog.info("LINUX", "${d.id} установлен")
        } catch (e: Throwable) {
            AppLog.error("LINUX", "ошибка установки ${d.id}", e)
            dir.deleteRecursively(); throw e
        } finally {
            tmp.delete()
        }
    }

    fun delete(id: String) { rootfs(id).deleteRecursively() }

    private fun extract(src: File, dir: File, url: String, onCount: (Int) -> Unit) {
        val raw = BufferedInputStream(src.inputStream(), 256 * 1024)
        val dec = if (url.endsWith(".xz")) XZCompressorInputStream(raw) else GzipCompressorInputStream(raw)
        val root = dir.canonicalFile
        var n = 0
        TarArchiveInputStream(dec).use { tar ->
            while (true) {
                val e = tar.nextTarEntry ?: break
                val name = e.name.removePrefix("./")
                if (name.isEmpty() || name == ".") continue
                val out = File(root, name)
                if (!out.canonicalPath.startsWith(root.path) && !e.isSymbolicLink) continue
                try {
                    when {
                        e.isDirectory -> { out.mkdirs(); chmod(out, e.mode or 0x1C0) }
                        e.isSymbolicLink -> {
                            out.parentFile?.mkdirs(); out.delete()
                            Os.symlink(e.linkName, out.path)
                        }
                        e.isLink -> {
                            out.parentFile?.mkdirs(); out.delete()
                            val t = File(root, e.linkName.removePrefix("./"))
                            if (t.exists()) t.copyTo(out, true)
                        }
                        e.isFile -> {
                            out.parentFile?.mkdirs(); out.delete()
                            out.outputStream().use { tar.copyTo(it) }
                            chmod(out, e.mode or 0x180)
                        }
                        else -> {} // устройства/fifo пропускаем: /dev берём у Android
                    }
                } catch (t: Throwable) {
                    AppLog.error("LINUX", "пропущен файл $name: ${t.message}")
                }
                if (++n % 500 == 0) onCount(n)
            }
        }
    }

    private fun chmod(f: File, mode: Int) { try { Os.chmod(f.path, mode and 0xFFF) } catch (_: Throwable) {} }

    // ---------------- запуск команд ----------------

    private fun vars(s: Settings): Map<String, String> = mapOf(
        "{proot}" to prootBin.path,
        "{rootfs}" to rootfs(s.distro).path,
        "{loader}" to loaderBin.path,
        "{libs}" to File(ctx.filesDir, "libs").path,
        "{cache}" to ctx.cacheDir.path,
        "{files}" to ctx.filesDir.path,
    )

    private fun expand(line: String, v: Map<String, String>): String {
        var r = line
        v.forEach { (k, x) -> r = r.replace(k, x) }
        return r
    }

    /** Собирает командную строку proot из редактируемого шаблона. */
    fun buildArgs(s: Settings, cmd: String, verbose: Boolean = false): List<String> {
        val v = vars(s)
        val out = ArrayList<String>()
        for (raw in s.prootArgs.lines()) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            when (line) {
                "{cmd}" -> out += cmd
                "{storage}" -> if (s.bindStorage && File("/sdcard").exists()) { out += "-b"; out += "/sdcard:/sdcard" }
                "{verbose}" -> if (verbose) { out += "-v"; out += "3" }
                else -> out += expand(line, v)
            }
        }
        return out
    }

    private fun prepEnv(pb: ProcessBuilder, s: Settings, proot: Boolean) {
        val env = pb.environment()
        if (!proot) {
            val home = File(ctx.filesDir, "home").apply { mkdirs() }
            env["HOME"] = home.path
            pb.directory(home)
            return
        }
        pb.directory(ctx.filesDir)
        val v = vars(s)
        for (l in s.prootEnv.lines()) {
            val t = l.trim()
            if (t.isEmpty() || t.startsWith("#") || !t.contains('=')) continue
            env[t.substringBefore('=')] = expand(t.substringAfter('='), v)
        }
        if (loaderBin.exists()) {
            env["PROOT_LOADER"] = loaderBin.path
            // proot из Termux ищет libtalloc.so.2, а Android распаковывает только lib*.so, поэтому делаем ссылку
            val d = File(ctx.filesDir, "libs").apply { mkdirs() }
            val link = File(d, "libtalloc.so.2")
            try { link.delete(); Os.symlink(File(nativeDir, "libtalloc.so").path, link.path) } catch (_: Throwable) {}
            env["LD_LIBRARY_PATH"] = d.path + ":" + nativeDir
        }
    }

    /** Возвращает (вывод, код выхода или null при таймауте). */
    private suspend fun runProc(args: List<String>, s: Settings, proot: Boolean, timeoutSec: Long, maxChars: Int): Pair<String, Int?> =
        withContext(Dispatchers.IO) {
            val pb = ProcessBuilder(args).redirectErrorStream(true)
            prepEnv(pb, s, proot)
            val proc = pb.start()
            val sb = StringBuilder()
            val reader = thread(isDaemon = true) {
                try {
                    proc.inputStream.bufferedReader().use { r ->
                        val buf = CharArray(4096)
                        while (true) {
                            val k = r.read(buf)
                            if (k < 0) break
                            synchronized(sb) { if (sb.length < maxChars * 8) sb.append(buf, 0, k) }
                        }
                    }
                } catch (_: Throwable) {}
            }
            try {
                val finished = runInterruptible { proc.waitFor(timeoutSec, TimeUnit.SECONDS) }
                if (!finished) proc.destroyForcibly()
                reader.join(2000)
                var text = synchronized(sb) { sb.toString() }
                if (text.length > maxChars) text = "…(обрезано)\n" + text.takeLast(maxChars)
                text to (if (finished) proc.exitValue() else null)
            } finally {
                if (proc.isAlive) proc.destroyForcibly()
            }
        }

    /** Выполняет команду: в Linux через proot или прямо в оболочке Android. */
    suspend fun exec(s: Settings, cmd: String): String {
        val isProot = s.runtime != "android"
        val args = if (isProot) buildArgs(s, cmd) else listOf("/system/bin/sh", "-c", cmd)
        val (text, code) = runProc(args, s, isProot, s.timeoutI, s.maxOutI)
        AppLog.info("EXEC", "[${if (isProot) s.distro else "android"}] ${cmd.take(200)} -> exit=$code, ${text.length} симв.")
        val tail = if (code != null) "[exit $code]" else "[таймаут ${s.timeoutI}с, процесс убит]"
        return when {
            text.isBlank() && code != null && code != 0 -> "(пустой вывод) $tail\nПодсказка: Настройки → Диагностика, и страница Логи."
            text.isBlank() -> tail
            else -> text.trimEnd() + "\n" + tail
        }
    }

    /** Диагностика: показывает, что реально происходит с proot. */
    suspend fun diagnose(s: Settings): String {
        val sb = StringBuilder()
        val root = rootfs(s.distro)
        sb.appendLine("sdk=${Build.VERSION.SDK_INT} abi=${Build.SUPPORTED_ABIS.joinToString()}")
        sb.appendLine("libs: " + (File(nativeDir).list()?.joinToString() ?: "?"))
        sb.appendLine("proot из Termux (есть loader): ${loaderBin.exists()}")
        sb.appendLine("rootfs установлен: ${installed(s.distro)}, файлов в /bin: ${File(root, "bin").list()?.size}")
        sb.appendLine("/bin/sh это symlink: ${java.nio.file.Files.isSymbolicLink(File(root, "bin/sh").toPath())}")
        try {
            val v = runProc(listOf(prootBin.path, "--version"), s, true, 15, 3000)
            sb.appendLine("\n== proot --version (exit ${v.second})\n${v.first}")
            val args = buildArgs(s, "echo hello; uname -a", verbose = true)
            val t = runProc(args, s, true, 30, 6000)
            sb.appendLine("\n== тестовый запуск, verbose (exit ${t.second})\n${t.first}")
        } catch (e: Throwable) {
            sb.appendLine("\nОшибка запуска: $e")
        }
        AppLog.info("DIAG", sb.toString())
        return sb.toString()
    }
}
