package com.agentbox.app

import android.content.Context

/** Заглушка: LiteRT-LM (Gemma 4, .litertlm) вернётся в следующей версии, когда базовая сборка подтвердится. */
class LiteRtEngine(@Suppress("UNUSED_PARAMETER") ctx: Context, @Suppress("UNUSED_PARAMETER") path: String, @Suppress("UNUSED_PARAMETER") gpu: Boolean) : LocalEngine {
    init { error("Движок LiteRT-LM отключён в этой сборке. Используй модели .task (MediaPipe).") }
    override fun generate(system: String, msgsJson: String, prompt: String): String = ""
    override fun close() {}
}
