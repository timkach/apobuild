package com.agentbox.app

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import org.json.JSONArray

/** Движок LiteRT-LM: модели .litertlm (Gemma 4, Qwen3 и др.). */
class LiteRtEngine(ctx: Context, path: String, gpu: Boolean) : LocalEngine {
    private val engine: Engine = Engine(
        EngineConfig(
            modelPath = path,
            backend = if (gpu) Backend.GPU() else Backend.CPU(),
            cacheDir = ctx.cacheDir.path,
        ),
    ).also { it.initialize() }

    override fun generate(system: String, msgsJson: String, prompt: String): String {
        val arr = JSONArray(msgsJson)
        val turns = (0 until arr.length()).map { arr.getJSONObject(it) }.filter { it.getString("role") != "system" }
        val last = turns.lastOrNull()?.getString("content") ?: ""
        val before = turns.dropLast(1)
        // Conversation хранит историю сам, поэтому прошлые реплики отдаём одним текстом
        val text = if (before.isEmpty()) last else buildString {
            append("Conversation so far:\n")
            before.forEach {
                append(if (it.getString("role") == "assistant") "ASSISTANT: " else "USER: ")
                append(it.getString("content")).append("\n\n")
            }
            append("Continue as ASSISTANT. Latest USER message:\n").append(last)
        }
        val cfg = ConversationConfig(systemInstruction = Contents.of(system))
        return engine.createConversation(cfg).use { it.sendMessage(text).toString() }
    }

    override fun close() { engine.close() }
}
