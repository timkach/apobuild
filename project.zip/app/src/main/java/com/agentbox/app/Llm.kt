package com.agentbox.app

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Msg(val role: String, val content: String)

interface Llm { suspend fun chat(msgs: List<Msg>): String }

class ApiLlm(private val baseUrl: String, private val key: String, private val model: String, private val temp: Double) : Llm {
    override suspend fun chat(msgs: List<Msg>): String = withContext(Dispatchers.IO) {
        val arr = JSONArray()
        msgs.forEach { arr.put(JSONObject().put("role", it.role).put("content", it.content)) }
        val body = JSONObject().put("model", model).put("temperature", temp).put("messages", arr)
        val c = URL(baseUrl.trimEnd('/') + "/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 20000
        c.readTimeout = 300000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        if (key.isNotBlank()) c.setRequestProperty("Authorization", "Bearer $key")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        if (code !in 200..299) error("API $code: ${text.take(400)}")
        JSONObject(text).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    }
}

class LocalLlm(private val ctx: Context, private val path: String, private val maxTokens: Int, private val gpu: Boolean) : Llm {
    var template = "gemma"
    private var eng: LlmInference? = null

    private fun engine(): LlmInference {
        eng?.let { return it }
        val opts = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(path)
            .setMaxTokens(maxTokens)
            .setPreferredBackend(if (gpu) LlmInference.Backend.GPU else LlmInference.Backend.CPU)
            .build()
        return LlmInference.createFromOptions(ctx, opts).also { eng = it }
    }

    fun close() { try { eng?.close() } catch (_: Throwable) {}; eng = null }

    override suspend fun chat(msgs: List<Msg>): String = withContext(Dispatchers.Default) {
        engine().generateResponse(format(msgs))
    }

    private fun format(msgs: List<Msg>): String {
        val sys = msgs.filter { it.role == "system" }.joinToString("\n") { it.content }
        val rest = msgs.filter { it.role != "system" }
        val sb = StringBuilder()
        if (template == "chatml") {
            if (sys.isNotEmpty()) sb.append("<|im_start|>system\n$sys<|im_end|>\n")
            rest.forEach { sb.append("<|im_start|>${it.role}\n${it.content}<|im_end|>\n") }
            sb.append("<|im_start|>assistant\n")
        } else {
            rest.forEachIndexed { i, m ->
                val role = if (m.role == "assistant") "model" else "user"
                val text = if (i == 0 && sys.isNotEmpty()) "$sys\n\n${m.content}" else m.content
                sb.append("<start_of_turn>$role\n$text<end_of_turn>\n")
            }
            sb.append("<start_of_turn>model\n")
        }
        return sb.toString()
    }
}

/** Модель грузится долго, поэтому держим её в памяти, пока настройки не изменились. */
object LlmCache {
    private var key = ""
    private var llm: LocalLlm? = null

    @Synchronized
    fun get(ctx: Context, path: String, maxTokens: Int, gpu: Boolean, template: String): LocalLlm {
        val k = "$path|$maxTokens|$gpu"
        if (k != key || llm == null) {
            llm?.close()
            llm = LocalLlm(ctx.applicationContext, path, maxTokens, gpu)
            key = k
        }
        return llm!!.also { it.template = template }
    }
}
