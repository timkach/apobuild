package com.agentbox.app

import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import kotlinx.coroutines.CancellableContinuation
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class Msg(val role: String, val content: String)

interface Llm { suspend fun chat(msgs: List<Msg>): String }

class ApiLlm(private val baseUrl: String, private val key: String, private val model: String, private val temp: Double) : Llm {
    override suspend fun chat(msgs: List<Msg>): String = withContext(Dispatchers.IO) {
        val arr = JSONArray()
        msgs.forEach { arr.put(JSONObject().put("role", it.role).put("content", it.content)) }
        val body = JSONObject().put("model", model).put("temperature", temp).put("messages", arr)
        val url = baseUrl.trimEnd('/') + "/chat/completions"
        AppLog.info("API", "POST $url model=$model сообщений=${msgs.size}")
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 20000
            c.readTimeout = 300000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            if (key.isNotBlank()) c.setRequestProperty("Authorization", "Bearer $key")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
            if (code !in 200..299) {
                AppLog.error("API", "HTTP $code: ${text.take(500)}")
                error("API $code: ${text.take(300)}")
            }
            JSONObject(text).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        } finally { c.disconnect() }
    }
}

/** Локальная модель: запросы уходят в отдельный процесс :llm, чтобы сбой модели не ронял приложение. */
class LocalLlm(
    private val ctx: Context, private val engine: String, private val path: String,
    private val maxTokens: Int, private val gpu: Boolean, private val tpl: Template,
) : Llm {
    override suspend fun chat(msgs: List<Msg>): String {
        val arr = JSONArray()
        msgs.forEach { arr.put(JSONObject().put("role", it.role).put("content", it.content)) }
        val b = Bundle().apply {
            putString("engine", engine); putString("path", path)
            putInt("maxTokens", maxTokens); putBoolean("gpu", gpu)
            putString("system", msgs.filter { it.role == "system" }.joinToString("\n") { it.content })
            putString("msgs", arr.toString())
            putString("prompt", Templates.render(tpl, msgs))
        }
        return LlmClient.generate(ctx, b)
    }
}

object LlmClient {
    private var messenger: Messenger? = null
    private var bound = false
    private var connDeferred: CompletableDeferred<Messenger>? = null
    private val pending = ConcurrentHashMap<Int, CancellableContinuation<String>>()
    private var nextId = 1
    private var appCtx: Context? = null

    private val replyHandler = Handler(Looper.getMainLooper()) { m ->
        val c = pending.remove(m.arg1)
        if (c != null && c.isActive) {
            if (m.what == MSG_OK) c.resume(m.data.getString("text") ?: "")
            else c.resumeWithException(IllegalStateException(m.data.getString("error") ?: "ошибка движка"))
        }
        true
    }
    private val replyTo = Messenger(replyHandler)

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
            val m = Messenger(b)
            messenger = m
            connDeferred?.complete(m)
            AppLog.info("LLM", "сервис модели подключён")
        }
        override fun onServiceDisconnected(n: ComponentName?) {
            AppLog.error("LLM", "процесс модели завершился")
            messenger = null
            logExit()
            failAll("Процесс модели завершился (скорее всего не хватило памяти или нативный сбой). Подробности в Логах.")
            resetBinding()
        }
        override fun onBindingDied(n: ComponentName?) { onServiceDisconnected(n) }
    }

    private fun failAll(msg: String) {
        val ids = pending.keys.toList()
        ids.forEach { id -> pending.remove(id)?.let { if (it.isActive) it.resumeWithException(IllegalStateException(msg)) } }
    }

    private fun resetBinding() {
        try { appCtx?.unbindService(conn) } catch (_: Throwable) {}
        bound = false
        messenger = null
        connDeferred = null
    }

    private fun logExit() {
        if (Build.VERSION.SDK_INT < 30) return
        try {
            val ctx = appCtx ?: return
            val am = ctx.getSystemService(ActivityManager::class.java)
            val e = am.getHistoricalProcessExitReasons(ctx.packageName, 0, 8).firstOrNull { it.processName.endsWith(":llm") } ?: return
            val name = when (e.reason) {
                ApplicationExitInfo.REASON_LOW_MEMORY -> "LOW_MEMORY (убит системой: мало памяти)"
                ApplicationExitInfo.REASON_CRASH_NATIVE -> "CRASH_NATIVE (нативный сбой)"
                ApplicationExitInfo.REASON_CRASH -> "CRASH (исключение)"
                ApplicationExitInfo.REASON_SIGNALED -> "SIGNALED"
                ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE -> "EXCESSIVE_RESOURCE_USAGE"
                else -> "reason=${e.reason}"
            }
            AppLog.error("LLM", "причина завершения: $name, status=${e.status}, описание: ${e.description}")
        } catch (t: Throwable) { AppLog.error("LLM", "не удалось получить причину завершения", t) }
    }

    private suspend fun ensureConnected(ctx: Context): Messenger {
        appCtx = ctx.applicationContext
        messenger?.let { return it }
        val d = connDeferred ?: CompletableDeferred<Messenger>().also { connDeferred = it }
        if (!bound) {
            bound = appCtx!!.bindService(Intent(appCtx, LlmService::class.java), conn, Context.BIND_AUTO_CREATE)
            if (!bound) { connDeferred = null; error("Не удалось запустить сервис модели") }
        }
        return try { withTimeout(20000) { d.await() } } catch (t: Throwable) { resetBinding(); throw t }
    }

    /** Останавливает процесс модели (единственный надёжный способ прервать генерацию). */
    fun kill() {
        try { messenger?.send(Message.obtain(null, MSG_KILL)) } catch (_: Throwable) {}
        resetBinding()
    }

    suspend fun generate(ctx: Context, data: Bundle): String {
        val m = ensureConnected(ctx)
        return suspendCancellableCoroutine { cont ->
            val id = synchronized(this) { nextId++ }
            pending[id] = cont
            cont.invokeOnCancellation { pending.remove(id); AppLog.info("LLM", "запрос отменён, останавливаю процесс модели"); kill() }
            val msg = Message.obtain(null, MSG_GEN, id, 0)
            msg.data = data
            msg.replyTo = replyTo
            try { m.send(msg) } catch (t: Throwable) {
                pending.remove(id)
                resetBinding()
                if (cont.isActive) cont.resumeWithException(t)
            }
        }
    }
}
