package com.agentbox.app

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.clickable
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

@Composable
fun App(vm: AgentVM = viewModel()) {
    var page by remember { mutableStateOf("chat") }
    BackHandler(page == "settings") { page = "chat" }
    if (page == "chat") ChatScreen(vm) { page = "settings" } else SettingsScreen(vm) { page = "chat" }
}

@Composable
fun ChatScreen(vm: AgentVM, openSettings: () -> Unit) {
    var input by remember { mutableStateOf("") }
    val list = rememberLazyListState()
    LaunchedEffect(vm.messages.size, vm.messages.lastOrNull()?.text) {
        if (vm.messages.isNotEmpty()) list.animateScrollToItem(vm.messages.lastIndex)
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("AgentBox", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            TextButton(onClick = { vm.s.mode = if (vm.s.mode == "local") "api" else "local" }) {
                Text(if (vm.s.mode == "local") "🧠 Локальный" else "☁ API")
            }
            TextButton(onClick = { vm.newChat() }) { Text("🗑") }
            TextButton(onClick = openSettings) { Text("⚙") }
        }
        HorizontalDivider()
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp), state = list, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (vm.messages.isEmpty()) item {
                Text("Опиши задачу. Агент сам выполняет команды в Linux (${vm.s.distro}) и отчитывается.\nПеред первым запуском установи Linux и модель в ⚙.",
                    Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(vm.messages) { Bubble(it) }
        }
        HorizontalDivider()
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.Bottom) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Задача для агента…") }, maxLines = 5)
            Spacer(Modifier.width(8.dp))
            Button(onClick = {
                if (vm.running) vm.stop() else if (input.isNotBlank()) { vm.send(input.trim()); input = "" }
            }) { Text(if (vm.running) "■" else "➤") }
        }
    }
    vm.pendingCmd?.let { cmd ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Выполнить команду?") },
            text = { SelectionContainer { Text(cmd, fontFamily = FontFamily.Monospace, fontSize = 13.sp) } },
            confirmButton = { TextButton(onClick = { vm.answer(true) }) { Text("Выполнить") } },
            dismissButton = { TextButton(onClick = { vm.answer(false) }) { Text("Отклонить") } },
        )
    }
}

@Composable
fun Bubble(m: UiMsg) {
    val cs = MaterialTheme.colorScheme
    val bg = when (m.kind) {
        "user" -> cs.primaryContainer
        "cmd" -> cs.tertiaryContainer
        "out" -> cs.surfaceVariant
        "sys" -> cs.errorContainer
        else -> cs.secondaryContainer
    }
    val mono = m.kind == "cmd" || m.kind == "out"
    val text = when (m.kind) { "cmd" -> "$ ${m.text}"; "out" -> m.text.take(3000); else -> m.text }
    Box(Modifier.fillMaxWidth(), contentAlignment = if (m.kind == "user") Alignment.CenterEnd else Alignment.CenterStart) {
        Surface(color = bg, shape = RoundedCornerShape(12.dp), modifier = Modifier.widthIn(max = 340.dp)) {
            SelectionContainer {
                Text(text, Modifier.padding(10.dp), fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default, fontSize = if (mono) 12.sp else 15.sp)
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: AgentVM, back: () -> Unit) {
    val s = vm.s
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.importModel(uri) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = back) { Text("← Назад") }
            Text("Настройки", style = MaterialTheme.typography.titleLarge)
        }

        Sec("Режим ИИ")
        Chips(listOf("local" to "🧠 Локальный", "api" to "☁ API"), s.mode) { s.mode = it }

        Sec("Linux (proot, без root)")
        Chips(DISTROS.map { it.id to it.title }, s.distro) { s.distro = it }
        val inst = vm.isInstalled(s.distro)
        Text(if (inst) "Статус: установлен ✔" else "Статус: не установлен", color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (s.distro == "arch") Text("Arch ~500 МБ в архиве и ~1.5 ГБ на диске.", fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { vm.installDistro(s.distro) }) { Text(if (inst) "Переустановить" else "Скачать и установить") }
            if (inst) OutlinedButton(onClick = { vm.deleteDistro(s.distro) }) { Text("Удалить") }
        }
        if (vm.linuxStatus.isNotEmpty()) Text(vm.linuxStatus, fontSize = 13.sp)
        Sw("Доступ к /sdcard внутри Linux", s.bindStorage) { s.bindStorage = it }

        Sec("Локальная модель (MediaPipe .task)")
        if (vm.modelList.isEmpty()) Text("Моделей нет. Загрузи по ссылке или импортируй файл .task.", fontSize = 13.sp)
        vm.modelList.forEach { n ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = s.localModel == n, onClick = { s.localModel = n })
                Text(n, Modifier.weight(1f).clickable { s.localModel = n }, fontSize = 14.sp)
                TextButton(onClick = { vm.deleteModel(n) }) { Text("🗑") }
            }
        }
        Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Импортировать .task из памяти") }
        Field("URL модели (.task)", s.modelUrl) { s.modelUrl = it }
        Field("HuggingFace токен (для Gemma)", s.hfToken, secret = true) { s.hfToken = it }
        OutlinedButton(onClick = { vm.downloadModel() }) { Text("Скачать по URL") }
        if (vm.modelStatus.isNotEmpty()) Text(vm.modelStatus, fontSize = 13.sp)
        Text("Шаблон чата", fontSize = 13.sp)
        Chips(listOf("gemma" to "Gemma", "chatml" to "ChatML (Qwen и др.)"), s.template) { s.template = it }
        Field("Макс. токенов (контекст)", s.maxTokens, number = true) { s.maxTokens = it }
        Sw("GPU вместо CPU", s.gpu) { s.gpu = it }

        Sec("API (OpenAI-совместимый)")
        Field("Base URL", s.apiUrl) { s.apiUrl = it }
        Field("API ключ", s.apiKey, secret = true) { s.apiKey = it }
        Field("Модель", s.apiModel) { s.apiModel = it }
        Field("Температура", s.temperature) { s.temperature = it }

        Sec("Агент")
        Field("Макс. шагов за запрос", s.maxSteps, number = true) { s.maxSteps = it }
        Field("Таймаут команды, сек", s.timeout, number = true) { s.timeout = it }
        Field("Лимит вывода команды, символов", s.maxOut, number = true) { s.maxOut = it }
        Sw("Спрашивать подтверждение перед командой", s.confirm) { s.confirm = it }

        Sec("Системный промпт")
        Text("Плейсхолдеры: {distro}, {pkg}", fontSize = 12.sp)
        Field("Промпт", s.systemPrompt, lines = 10) { s.systemPrompt = it }
        OutlinedButton(onClick = { s.systemPrompt = DEFAULT_PROMPT }) { Text("Сбросить по умолчанию") }
        Spacer(Modifier.height(32.dp))
    }
}

@Composable fun Sec(t: String) {
    Spacer(Modifier.height(8.dp))
    Text(t, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
}

@Composable fun Sw(label: String, v: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f)); Switch(v, onChange)
    }
}

@Composable fun Chips(items: List<Pair<String, String>>, sel: String, onSel: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { (id, label) -> FilterChip(selected = sel == id, onClick = { onSel(id) }, label = { Text(label) }) }
    }
}

@Composable fun Field(label: String, value: String, secret: Boolean = false, number: Boolean = false, lines: Int = 1, onChange: (String) -> Unit) {
    OutlinedTextField(
        value, onChange, Modifier.fillMaxWidth(), label = { Text(label) },
        singleLine = lines == 1, minLines = lines,
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (number) KeyboardType.Number else KeyboardType.Text),
    )
}
