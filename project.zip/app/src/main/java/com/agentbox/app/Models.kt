package com.agentbox.app

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class ModelManager(private val ctx: Context) {
    val dir: File get() = File(ctx.filesDir, "models").also { it.mkdirs() }

    fun list(): List<String> = dir.listFiles()
        ?.filter { it.isFile && (it.name.endsWith(".task") || it.name.endsWith(".litertlm")) }
        ?.map { it.name }?.sorted() ?: emptyList()

    fun delete(name: String) {
        File(dir, name).delete()
        dir.listFiles()?.filter { it.name.startsWith(name) }?.forEach { it.delete() } // кэши движка
    }

    suspend fun download(url: String, token: String?, onStatus: (String) -> Unit): String = withContext(Dispatchers.IO) {
        val name = url.substringBefore('?').substringAfterLast('/').ifBlank { "model.task" }
        val part = File(dir, "$name.part")
        try {
            AppLog.info("MODEL", "скачивание $url")
            Net.download(url, part, token) { d, t ->
                onStatus("Загрузка $name: ${d / 1_000_000} / ${if (t > 0) t / 1_000_000 else "?"} МБ")
            }
            val dest = File(dir, name)
            dest.delete(); part.renameTo(dest)
            AppLog.info("MODEL", "скачано: $name (${dest.length() / 1_000_000} МБ)")
            name
        } catch (e: Throwable) { part.delete(); AppLog.error("MODEL", "ошибка скачивания", e); throw e }
    }

    suspend fun import(uri: Uri, onStatus: (String) -> Unit): String = withContext(Dispatchers.IO) {
        var name = "model.task"
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: name
        }
        val part = File(dir, "$name.part")
        try {
            ctx.contentResolver.openInputStream(uri)!!.use { input ->
                part.outputStream().use { out -> Net.copy(input, out, -1) { d, _ -> onStatus("Копирование $name: ${d / 1_000_000} МБ") } }
            }
            val dest = File(dir, name)
            dest.delete(); part.renameTo(dest)
            AppLog.info("MODEL", "импортировано: $name")
            name
        } catch (e: Throwable) { part.delete(); AppLog.error("MODEL", "ошибка импорта", e); throw e }
    }
}
