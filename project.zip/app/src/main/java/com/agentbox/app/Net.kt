package com.agentbox.app

import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

object Net {
    /** Скачивание с ручной обработкой редиректов (токен шлём только на исходный хост). */
    suspend fun download(url: String, dest: File, token: String?, onProgress: (Long, Long) -> Unit) {
        var cur = url
        val origHost = URL(url).host
        repeat(10) {
            val c = URL(cur).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 20000
            c.readTimeout = 60000
            c.setRequestProperty("User-Agent", "AgentBox/1.0")
            if (!token.isNullOrBlank() && URL(cur).host == origHost) c.setRequestProperty("Authorization", "Bearer $token")
            val code = c.responseCode
            if (code in 300..399) {
                cur = URL(URL(cur), c.getHeaderField("Location")).toString()
                c.disconnect()
                return@repeat
            }
            if (code == 401 || code == 403) throw IOException("HTTP $code: нужен HF-токен и принятая лицензия модели")
            if (code !in 200..299) throw IOException("HTTP $code")
            val total = c.contentLengthLong
            c.inputStream.use { input -> dest.outputStream().use { out -> copy(input, out, total, onProgress) } }
            return
        }
        throw IOException("Слишком много редиректов")
    }

    suspend fun copy(input: InputStream, out: java.io.OutputStream, total: Long, onProgress: (Long, Long) -> Unit) {
        val buf = ByteArray(256 * 1024)
        var done = 0L
        var last = 0L
        while (true) {
            currentCoroutineContext().ensureActive()
            val n = input.read(buf)
            if (n < 0) break
            out.write(buf, 0, n)
            done += n
            if (done - last > 1_000_000) { last = done; onProgress(done, total) }
        }
        onProgress(done, total)
    }
}
