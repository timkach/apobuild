package com.agentbox.app

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/** Всё, что здесь меняется, применяется сразу, без пересборки приложения. */
@Composable
fun AdvancedScreen(vm: AgentVM, back: () -> Unit) {
    val s = vm.s
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = back) { Text("← Назад") }
            Text("Расширенное", style = MaterialTheme.typography.titleLarge)
        }
        Hint("Эти куски раньше были зашиты в код. Теперь их можно менять на лету. Некорректное значение приложение заменит стандартным и запишет ошибку в логи.")

        Sec("Системный промпт")
        Hint("Плейсхолдеры: {distro}, {pkg}")
        Field("Промпт", s.systemPrompt, lines = 10) { s.systemPrompt = it }
        OutlinedButton(onClick = { s.systemPrompt = DEFAULT_PROMPT }) { Text("Сбросить") }

        Sec("Как искать команду в ответе модели")
        Hint("Регулярное выражение, группа 1 = текст команды.")
        Field("Regex", s.cmdRegexText, lines = 2, mono = true) { s.cmdRegexText = it }
        val reErr = remember(s.cmdRegexText) { try { Regex(s.cmdRegexText); "" } catch (t: Throwable) { t.message ?: "ошибка" } }
        if (reErr.isNotEmpty()) Text(reErr, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        OutlinedButton(onClick = { s.cmdRegexText = DEFAULT_REGEX }) { Text("Сбросить") }

        Sec("Запуск proot: аргументы")
        Hint("По одному аргументу на строку. Плейсхолдеры: {proot} {rootfs} {cmd} {loader} {libs} {cache} {files}. Спец-строки: {storage} (доступ к sdcard), {verbose} (подробный режим диагностики).")
        Field("Аргументы", s.prootArgs, lines = 12, mono = true) { s.prootArgs = it }
        OutlinedButton(onClick = { s.prootArgs = DEFAULT_PROOT_ARGS }) { Text("Сбросить") }

        Sec("Запуск proot: переменные окружения")
        Hint("КЛЮЧ=ЗНАЧЕНИЕ, по одной на строку. Строки с # игнорируются.")
        Field("Окружение", s.prootEnv, lines = 3, mono = true) { s.prootEnv = it }
        OutlinedButton(onClick = { s.prootEnv = DEFAULT_PROOT_ENV }) { Text("Сбросить") }

        Sec("Шаблоны чата (JSON)")
        Hint("Для каждой модели свои теги. Поля: system, user, assistant, generation, bos, systemInUser. {content} подставляется автоматически.")
        Field("JSON шаблонов", s.templatesJson, lines = 8, mono = true) { s.templatesJson = it }
        val tErr = remember(s.templatesJson) { try { Templates.parse(s.templatesJson); "" } catch (t: Throwable) { t.message ?: "ошибка" } }
        if (tErr.isNotEmpty()) Text("Ошибка JSON: $tErr", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        OutlinedButton(onClick = { s.templatesJson = DEFAULT_TEMPLATES }) { Text("Сбросить") }

        Sec("Готовые модели (JSON)")
        Hint("Список кнопок в настройках локального ИИ. Поля: name, template, url, token (нужен ли HF токен), maxTokens.")
        Field("JSON пресетов", s.presetsJson, lines = 8, mono = true) { s.presetsJson = it }
        val pErr = remember(s.presetsJson) { try { Presets.parse(s.presetsJson); "" } catch (t: Throwable) { t.message ?: "ошибка" } }
        if (pErr.isNotEmpty()) Text("Ошибка JSON: $pErr", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        OutlinedButton(onClick = { s.presetsJson = DEFAULT_PRESETS }) { Text("Сбросить") }
        Spacer(Modifier.height(32.dp))
    }
}

@Composable
fun LogsScreen(back: () -> Unit) {
    var text by remember { mutableStateOf("") }
    val scroll = rememberScrollState()
    val clip = LocalClipboardManager.current
    val ctx = LocalContext.current
    LaunchedEffect(Unit) {
        while (true) {
            text = withContext(Dispatchers.IO) { AppLog.read() }
            delay(2000)
        }
    }
    LaunchedEffect(text.length) { scroll.animateScrollTo(scroll.maxValue) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TBtn("←") { back() }
            Text("Логи", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            TBtn("Копир.") { clip.setText(AnnotatedString(text)) }
            TBtn("Отпр.") {
                val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text.takeLast(50_000)) }
                ctx.startActivity(Intent.createChooser(i, "Логи AgentBox"))
            }
            TBtn("Очист.") { AppLog.clear(); text = "" }
        }
        HorizontalDivider()
        Box(Modifier.weight(1f).fillMaxWidth().verticalScroll(scroll).padding(8.dp)) {
            SelectionContainer {
                Text(text.ifEmpty { "Лог пуст" }, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            }
        }
    }
}
