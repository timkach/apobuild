package com.agentbox.app

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

class StrPref(private val p: SharedPreferences, private val k: String, d: String) : ReadWriteProperty<Any?, String> {
    private var st by mutableStateOf(p.getString(k, d) ?: d)
    override fun getValue(thisRef: Any?, property: KProperty<*>): String = st
    override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) {
        st = value; p.edit().putString(k, value).apply()
    }
}

class BoolPref(private val p: SharedPreferences, private val k: String, d: Boolean) : ReadWriteProperty<Any?, Boolean> {
    private var st by mutableStateOf(p.getBoolean(k, d))
    override fun getValue(thisRef: Any?, property: KProperty<*>): Boolean = st
    override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) {
        st = value; p.edit().putBoolean(k, value).apply()
    }
}

const val DEFAULT_PROMPT = """You are an autonomous agent running inside an Android app. You control a real Linux shell ({distro}) running via proot as root (home: /root, internet available). Package manager: {pkg}

To run a shell command, reply with exactly ONE fenced block and nothing after it:
```bash
your command here
```
You will then receive the command output as the next message and can continue. Work step by step, check results, fix errors. Prefer non-interactive commands (use -y flags, no editors).
When the task is finished, reply with the final answer in plain text WITHOUT any ```bash block. To show code to the user, use a block with another language tag (for example ```python).
Reply in the language the user writes in. Do not delete files outside /root unless the user explicitly asks."""

data class Distro(val id: String, val title: String, val url: String, val pkgHint: String)

val DISTROS = listOf(
    Distro("alpine", "Alpine", "https://dl-cdn.alpinelinux.org/alpine/v3.20/releases/aarch64/alpine-minirootfs-3.20.3-aarch64.tar.gz",
        "apk add <pkg> (run 'apk update' first)"),
    Distro("debian", "Debian 12", "https://github.com/debuerreotype/docker-debian-artifacts/raw/dist-arm64v8/bookworm/slim/rootfs.tar.xz",
        "apt-get -o APT::Sandbox::User=root update && apt-get -o APT::Sandbox::User=root install -y <pkg>"),
    Distro("arch", "Arch Linux ARM", "http://os.archlinuxarm.org/os/ArchLinuxARM-aarch64-latest.tar.gz",
        "pacman -Sy --noconfirm <pkg>"),
)

class Settings(ctx: Context) {
    private val p = ctx.getSharedPreferences("agentbox", Context.MODE_PRIVATE)

    var mode by StrPref(p, "mode", "local")            // local | api
    var distro by StrPref(p, "distro", "alpine")
    var systemPrompt by StrPref(p, "prompt", DEFAULT_PROMPT)

    var apiUrl by StrPref(p, "apiUrl", "https://api.openai.com/v1")
    var apiKey by StrPref(p, "apiKey", "")
    var apiModel by StrPref(p, "apiModel", "gpt-4o-mini")
    var temperature by StrPref(p, "temp", "0.4")

    var localModel by StrPref(p, "localModel", "")
    var modelUrl by StrPref(p, "modelUrl", "https://huggingface.co/litert-community/Gemma3-1B-IT/resolve/main/gemma3-1b-it-int4.task")
    var hfToken by StrPref(p, "hfToken", "")
    var template by StrPref(p, "template", "gemma")     // gemma | chatml
    var maxTokens by StrPref(p, "maxTokens", "4096")
    var gpu by BoolPref(p, "gpu", false)

    var maxSteps by StrPref(p, "maxSteps", "15")
    var timeout by StrPref(p, "timeout", "120")
    var maxOut by StrPref(p, "maxOut", "4000")
    var confirm by BoolPref(p, "confirm", true)
    var bindStorage by BoolPref(p, "bindStorage", true)

    val maxTokensI get() = maxTokens.toIntOrNull()?.coerceIn(512, 32768) ?: 4096
    val maxStepsI get() = maxSteps.toIntOrNull()?.coerceIn(1, 100) ?: 15
    val timeoutI get() = timeout.toLongOrNull()?.coerceIn(5, 3600) ?: 120L
    val maxOutI get() = maxOut.toIntOrNull()?.coerceIn(500, 50000) ?: 4000
}
