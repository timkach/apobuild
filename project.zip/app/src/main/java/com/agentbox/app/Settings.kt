package com.agentbox.app

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

class StrPref(private val p: SharedPreferences, private val k: String, d: String) : ReadWriteProperty<Any?, String> {
    private var st by mutableStateOf(p.getString(k, d) ?: d)
    override fun getValue(thisRef: Any?, property: KProperty<*>): String = st
    override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) {
        st = value; p.edit().putString(k, value).apply()
    }
}

class BoolPref(private val p: SharedPreferences, private val k: String, d: Boolean) : ReadWriteProperty<Any?, Boolean> {
    private var st by mutableStateOf(p.getBoolean(k, d))
    override fun getValue(thisRef: Any?, property: KProperty<*>): Boolean = st
    override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) {
        st = value; p.edit().putBoolean(k, value).apply()
    }
}

// ---------- значения по умолчанию (всё это можно менять в приложении: Настройки → Расширенное) ----------

const val DEFAULT_PROMPT = """You are an autonomous agent running inside an Android app. You control a shell: {distro}. Home: /root. Package manager: {pkg}

To run a shell command, reply with exactly ONE fenced block and nothing after it:
```bash
your command here
```
You will then receive the command output as the next message and can continue. Work step by step, check results, fix errors. Prefer non-interactive commands (use -y flags, no editors).
When the task is finished, reply with the final answer in plain text WITHOUT any ```bash block. To show code to the user, use a block with another language tag (for example ```python).
Reply in the language the user writes in. Do not delete files outside the home directory unless the user explicitly asks."""

/** Регулярка для поиска команды в ответе модели. Группа 1 = текст команды. */
const val DEFAULT_REGEX = """```(?:bash|sh|shell)[ \t]*\r?\n(.*?)```"""

/** Аргументы запуска proot, по одному на строку. Плейсхолдеры: {proot} {rootfs} {cmd} {loader} {libs} {cache} {files}, спец-строки {storage} и {verbose}. */
const val DEFAULT_PROOT_ARGS = """{proot}
{verbose}
--link2symlink
-0
--kill-on-exit
-r
{rootfs}
-b
/dev
-b
/proc
-b
/sys
{storage}
-w
/root
/usr/bin/env
-i
HOME=/root
USER=root
TERM=xterm
LANG=C.UTF-8
DEBIAN_FRONTEND=noninteractive
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
/bin/sh
-c
{cmd}"""

/** Переменные окружения процесса proot (КЛЮЧ=ЗНАЧЕНИЕ, по одной на строку). */
const val DEFAULT_PROOT_ENV = """PROOT_NO_SECCOMP=1
PROOT_TMP_DIR={cache}"""

/** Шаблоны чата для локальных моделей MediaPipe. {content} подставляется автоматически. */
const val DEFAULT_TEMPLATES = """{
 "gemma": {"user":"<start_of_turn>user\n{content}<end_of_turn>\n","assistant":"<start_of_turn>model\n{content}<end_of_turn>\n","generation":"<start_of_turn>model\n","systemInUser":true},
 "chatml": {"system":"<|im_start|>system\n{content}<|im_end|>\n","user":"<|im_start|>user\n{content}<|im_end|>\n","assistant":"<|im_start|>assistant\n{content}<|im_end|>\n","generation":"<|im_start|>assistant\n"},
 "llama3": {"system":"<|start_header_id|>system<|end_header_id|>\n\n{content}<|eot_id|>","user":"<|start_header_id|>user<|end_header_id|>\n\n{content}<|eot_id|>","assistant":"<|start_header_id|>assistant<|end_header_id|>\n\n{content}<|eot_id|>","generation":"<|start_header_id|>assistant<|end_header_id|>\n\n"},
 "phi3": {"system":"<|system|>\n{content}<|end|>\n","user":"<|user|>\n{content}<|end|>\n","assistant":"<|assistant|>\n{content}<|end|>\n","generation":"<|assistant|>\n"},
 "deepseek": {"system":"{content}","user":"<｜User｜>{content}","assistant":"<｜Assistant｜>{content}<｜end▁of▁sentence｜>","generation":"<｜Assistant｜>"},
 "plain": {"system":"{content}\n\n","user":"User: {content}\n","assistant":"Assistant: {content}\n","generation":"Assistant:"}
}"""

/** Список готовых моделей. engine: mediapipe | litertlm. */
const val DEFAULT_PRESETS = """[
 {"name":"Gemma 3 1B · MediaPipe · без токена (зеркало)","template":"gemma","url":"https://huggingface.co/nalsil/notivault-gemma3-mirror/resolve/main/gemma3-1b-it-int4.task","token":false,"maxTokens":1280},
 {"name":"Gemma 3 1B · MediaPipe · оригинал (нужен HF токен)","template":"gemma","url":"https://huggingface.co/litert-community/Gemma3-1B-IT/resolve/main/Gemma3-1B-IT_multi-prefill-seq_q4_block128_ekv4096.task","token":true,"maxTokens":4096},
 {"name":"Qwen2.5 1.5B · MediaPipe · q8","template":"chatml","url":"https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct/resolve/main/Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv1280.task","token":false,"maxTokens":1280}
]"""

data class Distro(val id: String, val title: String, val url: String, val pkgHint: String)

val DISTROS = listOf(
    Distro("alpine", "Alpine", "https://dl-cdn.alpinelinux.org/alpine/v3.20/releases/aarch64/alpine-minirootfs-3.20.3-aarch64.tar.gz",
        "apk add <pkg> (run 'apk update' first)"),
    Distro("debian", "Debian 12", "https://github.com/debuerreotype/docker-debian-artifacts/raw/dist-arm64v8/bookworm/slim/rootfs.tar.xz",
        "apt-get -o APT::Sandbox::User=root update && apt-get -o APT::Sandbox::User=root install -y <pkg>"),
    Distro("arch", "Arch Linux ARM", "http://os.archlinuxarm.org/os/ArchLinuxARM-aarch64-latest.tar.gz",
        "pacman -Sy --noconfirm <pkg>"),
)

data class ApiPreset(val name: String, val url: String, val model: String)

val API_PRESETS = listOf(
    ApiPreset("Groq", "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile"),
    ApiPreset("OpenAI", "https://api.openai.com/v1", "gpt-4o-mini"),
    ApiPreset("OpenRouter", "https://openrouter.ai/api/v1", "meta-llama/llama-3.3-70b-instruct"),
    ApiPreset("Ollama (localhost)", "http://127.0.0.1:11434/v1", "llama3.2"),
    ApiPreset("llama.cpp server (localhost)", "http://127.0.0.1:8080/v1", "local"),
)

data class Template(val bos: String, val system: String, val user: String, val assistant: String, val generation: String, val systemInUser: Boolean)

object Templates {
    fun parse(json: String): Map<String, Template> {
        val o = JSONObject(json)
        val m = LinkedHashMap<String, Template>()
        for (k in o.keys()) {
            val t = o.getJSONObject(k)
            m[k] = Template(
                t.optString("bos", ""), t.optString("system", ""), t.optString("user", "{content}"),
                t.optString("assistant", "{content}"), t.optString("generation", ""), t.optBoolean("systemInUser", false),
            )
        }
        require(m.isNotEmpty()) { "нет ни одного шаблона" }
        return m
    }

    fun render(t: Template, msgs: List<Msg>): String {
        val sys = msgs.filter { it.role == "system" }.joinToString("\n") { it.content }
        val rest = msgs.filter { it.role != "system" }
        val sb = StringBuilder(t.bos)
        if (sys.isNotEmpty() && !t.systemInUser) sb.append(t.system.replace("{content}", sys))
        rest.forEachIndexed { i, m ->
            val c = if (i == 0 && t.systemInUser && sys.isNotEmpty()) sys + "\n\n" + m.content else m.content
            sb.append((if (m.role == "assistant") t.assistant else t.user).replace("{content}", c))
        }
        sb.append(t.generation)
        return sb.toString()
    }
}

data class Preset(val name: String, val template: String, val url: String, val token: Boolean, val maxTokens: Int)

object Presets {
    fun parse(json: String): List<Preset> {
        val a = JSONArray(json)
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Preset(o.getString("name"), o.optString("template", "gemma"), o.getString("url"), o.optBoolean("token", false), o.optInt("maxTokens", 1280))
        }
    }
}

class Settings(ctx: Context) {
    private val p = ctx.getSharedPreferences("agentbox", Context.MODE_PRIVATE)

    // оформление
    var themeAccent by StrPref(p, "themeAccent", "purple")   // purple | red | orange
    var themeMode by StrPref(p, "themeMode", "system")       // system | dark | light

    // режим и ИИ
    var mode by StrPref(p, "mode", "local")                  // local | api
    var engine by StrPref(p, "engine", "auto")               // auto | mediapipe | litertlm
    var localModel by StrPref(p, "localModel", "")
    var modelUrl by StrPref(p, "modelUrl", "https://huggingface.co/nalsil/notivault-gemma3-mirror/resolve/main/gemma3-1b-it-int4.task")
    var hfToken by StrPref(p, "hfToken", "")
    var template by StrPref(p, "template", "gemma")
    var maxTokens by StrPref(p, "maxTokens", "1280")
    var gpu by BoolPref(p, "gpu", false)

    var apiUrl by StrPref(p, "apiUrl", "https://api.groq.com/openai/v1")
    var apiKey by StrPref(p, "apiKey", "")
    var apiModel by StrPref(p, "apiModel", "llama-3.3-70b-versatile")
    var temperature by StrPref(p, "temp", "0.4")

    // среда выполнения команд
    var runtime by StrPref(p, "runtime", "proot")            // proot | android
    var distro by StrPref(p, "distro", "alpine")
    var bindStorage by BoolPref(p, "bindStorage", true)
    var maxSteps by StrPref(p, "maxSteps", "15")
    var timeout by StrPref(p, "timeout", "120")
    var maxOut by StrPref(p, "maxOut", "4000")
    var confirm by BoolPref(p, "confirm", true)

    // редактируемые «куски кода»
    var systemPrompt by StrPref(p, "prompt", DEFAULT_PROMPT)
    var cmdRegexText by StrPref(p, "cmdRegex", DEFAULT_REGEX)
    var prootArgs by StrPref(p, "prootArgs", DEFAULT_PROOT_ARGS)
    var prootEnv by StrPref(p, "prootEnv", DEFAULT_PROOT_ENV)
    var templatesJson by StrPref(p, "templatesJson", DEFAULT_TEMPLATES)
    var presetsJson by StrPref(p, "presetsJson", DEFAULT_PRESETS)

    val maxTokensI get() = maxTokens.toIntOrNull()?.coerceIn(256, 32768) ?: 1280
    val maxStepsI get() = maxSteps.toIntOrNull()?.coerceIn(1, 100) ?: 15
    val timeoutI get() = timeout.toLongOrNull()?.coerceIn(5, 3600) ?: 120L
    val maxOutI get() = maxOut.toIntOrNull()?.coerceIn(500, 50000) ?: 4000

    fun cmdRegex(): Regex = try {
        Regex(cmdRegexText, RegexOption.DOT_MATCHES_ALL)
    } catch (t: Throwable) {
        AppLog.error("CFG", "Некорректная регулярка, использую стандартную: ${t.message}")
        Regex(DEFAULT_REGEX, RegexOption.DOT_MATCHES_ALL)
    }

    fun templates(): Map<String, Template> = try { Templates.parse(templatesJson) } catch (t: Throwable) {
        AppLog.error("CFG", "Ошибка в JSON шаблонов, использую стандартные: ${t.message}")
        Templates.parse(DEFAULT_TEMPLATES)
    }

    fun presets(): List<Preset> = try { Presets.parse(presetsJson) } catch (t: Throwable) {
        AppLog.error("CFG", "Ошибка в JSON пресетов, использую стандартные: ${t.message}")
        Presets.parse(DEFAULT_PRESETS)
    }
}
