package com.agentbox.app

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(vm: AgentVM, back: () -> Unit, openAdv: () -> Unit, openLogs: () -> Unit) {
    val s = vm.s
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.importModel(uri) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = back) { Text("← Назад") }
            Text("Настройки", style = MaterialTheme.typography.titleLarge)
        }

        Sec("Оформление")
        Chips(listOf("purple" to "🟣 Фиолетовая", "red" to "🔴 Красная", "orange" to "🟠 Оранжевая"), s.themeAccent) { s.themeAccent = it }
        Chips(listOf("system" to "Как в системе", "dark" to "Тёмная", "light" to "Светлая"), s.themeMode) { s.themeMode = it }

        Sec("Режим ИИ")
        Chips(listOf("local" to "🧠 Локальный", "api" to "☁ API"), s.mode) { s.mode = it }

        Sec("Локальный ИИ")
        Text("Движок (библиотека)", fontSize = 13.sp)
        Chips(listOf("auto" to "Авто по файлу", "mediapipe" to "MediaPipe (.task)", "litertlm" to "LiteRT-LM (скоро)"), s.engine) { s.engine = it }
        Hint("Сейчас работают модели .task (MediaPipe). LiteRT-LM (Gemma 4) вернётся в следующей версии. Модель работает в отдельном процессе, поэтому её сбой не роняет приложение.")
        Text("Готовые модели (список правится в «Расширенное»)", fontSize = 13.sp)
        vm.s.presets().forEach { p ->
            OutlinedButton(onClick = { vm.applyPreset(p) }, Modifier.fillMaxWidth()) { Text(p.name, fontSize = 13.sp) }
        }
        Text("Установленные модели", fontSize = 13.sp)
        if (vm.modelList.isEmpty()) Hint("Моделей нет. Выбери готовую выше и нажми «Скачать по URL», либо импортируй файл.")
        vm.modelList.forEach { n ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = s.localModel == n, onClick = { s.localModel = n })
                Text(n, Modifier.weight(1f).clickable { s.localModel = n }, fontSize = 14.sp)
                TextButton(onClick = { vm.deleteModel(n) }) { Text("🗑") }
            }
        }
        Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Импортировать файл модели") }
        Field("URL модели", s.modelUrl) { s.modelUrl = it }
        Field("HuggingFace токен (если модель закрытая)", s.hfToken, secret = true) { s.hfToken = it }
        OutlinedButton(onClick = { vm.downloadModel() }) { Text("Скачать по URL") }
        if (vm.modelStatus.isNotEmpty()) Text(vm.modelStatus, fontSize = 13.sp)
        Text("Шаблон чата (для MediaPipe)", fontSize = 13.sp)
        Chips(s.templates().keys.map { it to it }, s.template) { s.template = it }
        Field("Макс. токенов (контекст)", s.maxTokens, number = true) { s.maxTokens = it }
        Hint("Для .task с суффиксом ekv1280 ставь 1280, для ekv4096 ставь 4096. Слишком большое значение может уронить процесс модели.")
        Sw("GPU вместо CPU", s.gpu) { s.gpu = it }

        Sec("API (OpenAI-совместимый)")
        Chips(API_PRESETS.map { it.name to it.name }, "") { n ->
            API_PRESETS.first { it.name == n }.let { s.apiUrl = it.url; s.apiModel = it.model }
        }
        Field("Base URL", s.apiUrl) { s.apiUrl = it }
        Field("API ключ", s.apiKey, secret = true) { s.apiKey = it }
        Field("Модель", s.apiModel) { s.apiModel = it }
        Field("Температура", s.temperature) { s.temperature = it }
        Hint("GGUF-модели через llama.cpp server или Ollama: запусти сервер и выбери его пресет (localhost).")

        Sec("Среда выполнения команд")
        Chips(listOf("proot" to "🐧 Linux (proot)", "android" to "🤖 Android shell"), s.runtime) { s.runtime = it }
        if (s.runtime == "android") Hint("Команды идут прямо в оболочку Android (toybox). Без Linux и пакетного менеджера, но работает всегда, даже если proot сломан.")
        if (s.runtime == "proot") {
            Chips(DISTROS.map { it.id to it.title }, s.distro) { s.distro = it }
            val inst = vm.isInstalled(s.distro)
            Text(if (inst) "Статус: установлен ✔" else "Статус: не установлен", color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (s.distro == "arch") Hint("Arch: ~500 МБ в архиве и ~1.5 ГБ на диске.")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.installDistro(s.distro) }) { Text(if (inst) "Переустановить" else "Скачать и установить") }
                if (inst) OutlinedButton(onClick = { vm.deleteDistro(s.distro) }) { Text("Удалить") }
            }
            if (vm.linuxStatus.isNotEmpty()) Text(vm.linuxStatus, fontSize = 13.sp)
            Sw("Доступ к /sdcard внутри Linux", s.bindStorage) { s.bindStorage = it }
        }
        OutlinedButton(onClick = { vm.runDiag() }) { Text("🔧 Диагностика среды") }
        if (vm.diag.isNotEmpty()) SelectionContainer { Text(vm.diag, fontFamily = FontFamily.Monospace, fontSize = 11.sp) }

        Sec("Агент")
        Field("Макс. шагов за запрос", s.maxSteps, number = true) { s.maxSteps = it }
        Field("Таймаут команды, сек", s.timeout, number = true) { s.timeout = it }
        Field("Лимит вывода команды, символов", s.maxOut, number = true) { s.maxOut = it }
        Sw("Спрашивать подтверждение перед командой", s.confirm) { s.confirm = it }

        Sec("Ещё")
        Button(onClick = openAdv, Modifier.fillMaxWidth()) { Text("🧩 Расширенное: промпт, proot, шаблоны, пресеты") }
        OutlinedButton(onClick = openLogs, Modifier.fillMaxWidth()) { Text("📜 Логи") }
        Spacer(Modifier.height(32.dp))
    }
}
