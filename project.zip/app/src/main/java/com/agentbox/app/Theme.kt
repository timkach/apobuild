package com.agentbox.app

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp

private class Accent(val d: Long, val dOn: Long, val dCont: Long, val dOnCont: Long, val l: Long, val lOn: Long, val lCont: Long, val lOnCont: Long)

private val ACCENTS = mapOf(
    "purple" to Accent(0xFFD0BCFF, 0xFF381E72, 0xFF4F378B, 0xFFEADDFF, 0xFF6750A4, 0xFFFFFFFF, 0xFFEADDFF, 0xFF21005D),
    "red" to Accent(0xFFFFB3B1, 0xFF680012, 0xFF92001D, 0xFFFFDAD8, 0xFFC00018, 0xFFFFFFFF, 0xFFFFDAD8, 0xFF410004),
    "orange" to Accent(0xFFFFB784, 0xFF4F2500, 0xFF713700, 0xFFFFDCC4, 0xFF9A4600, 0xFFFFFFFF, 0xFFFFDCC4, 0xFF311300),
)

@Composable
fun AgentTheme(accent: String, mode: String, content: @Composable () -> Unit) {
    val dark = when (mode) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
    val a = ACCENTS[accent] ?: ACCENTS.getValue("purple")
    val scheme = if (dark) {
        val base = Color(0xFF1C1B1F)
        darkColorScheme(
            primary = Color(a.d), onPrimary = Color(a.dOn),
            primaryContainer = Color(a.dCont), onPrimaryContainer = Color(a.dOnCont),
            secondaryContainer = lerp(Color(a.dCont), base, 0.55f), onSecondaryContainer = Color(0xFFEEE6EA),
            tertiaryContainer = Color(0xFF1F4D4A), onTertiaryContainer = Color(0xFFBFF0EA),
        )
    } else {
        lightColorScheme(
            primary = Color(a.l), onPrimary = Color(a.lOn),
            primaryContainer = Color(a.lCont), onPrimaryContainer = Color(a.lOnCont),
            secondaryContainer = lerp(Color(a.lCont), Color.White, 0.5f), onSecondaryContainer = Color(0xFF1D1B20),
            tertiaryContainer = Color(0xFFC6EEE9), onTertiaryContainer = Color(0xFF00201E),
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
