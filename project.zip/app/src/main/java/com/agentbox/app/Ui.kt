package com.agentbox.app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable fun Sec(t: String) {
    Spacer(Modifier.height(10.dp))
    Text(t, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
}

@Composable fun Hint(t: String) = Text(t, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

@Composable fun Sw(label: String, v: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f)); Switch(v, onChange)
    }
}

@Composable fun Chips(items: List<Pair<String, String>>, sel: String, onSel: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { (id, label) -> FilterChip(selected = sel == id, onClick = { onSel(id) }, label = { Text(label) }) }
    }
}

@Composable fun TBtn(text: String, onClick: () -> Unit) {
    Box(Modifier.clickable { onClick() }.padding(horizontal = 10.dp, vertical = 10.dp)) { Text(text) }
}

@Composable fun Field(
    label: String, value: String, secret: Boolean = false, number: Boolean = false,
    lines: Int = 1, mono: Boolean = false, onChange: (String) -> Unit,
) {
    OutlinedTextField(
        value, onChange, Modifier.fillMaxWidth(), label = { Text(label) },
        singleLine = lines == 1, minLines = lines, maxLines = if (lines == 1) 1 else lines + 14,
        textStyle = LocalTextStyle.current.copy(fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default, fontSize = if (mono) 12.sp else 16.sp),
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (number) KeyboardType.Number else KeyboardType.Text),
    )
}
