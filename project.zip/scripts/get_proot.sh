#!/usr/bin/env bash
# Берёт proot, собранный под Android (Termux). При любой ошибке выходит с кодом 1,
# тогда остаётся то, что скачал workflow.
set -u
cd "$(dirname "$0")/.."
OUT="app/src/main/jniLibs/arm64-v8a"
mkdir -p "$OUT"
W="$(mktemp -d)"
BASE="https://packages.termux.dev/apt/termux-main"
curl -fsSL "$BASE/dists/stable/main/binary-aarch64/Packages" -o "$W/Packages" || { echo "[proot] нет индекса Termux"; exit 1; }
find_deb() {
  awk -v p="$1" 'BEGIN{RS="";FS="\n"} { ok=0; f=""; for(i=1;i<=NF;i++){ if($i==("Package: " p)) ok=1; if(index($i,"Filename: ")==1) f=substr($i,11) } if(ok){print f; exit} }' "$W/Packages"
}
P="$(find_deb proot)"; T="$(find_deb libtalloc)"
echo "[proot] deb: $P / $T"
{ [ -n "$P" ] && [ -n "$T" ]; } || exit 1
curl -fsSL "$BASE/$P" -o "$W/proot.deb" || exit 1
curl -fsSL "$BASE/$T" -o "$W/talloc.deb" || exit 1
mkdir -p "$W/p" "$W/t"
( cd "$W/p" && ar x ../proot.deb && tar xf data.tar.* ) || exit 1
( cd "$W/t" && ar x ../talloc.deb && tar xf data.tar.* ) || exit 1
PB="$(find "$W/p" -type f -path '*/bin/proot' | head -1)"
LD="$(find "$W/p" -type f -path '*/libexec/proot/loader' | head -1)"
TL="$(find "$W/t" -type f -name 'libtalloc.so*' | head -1)"
echo "[proot] $PB | $LD | $TL"
{ [ -n "$PB" ] && [ -n "$LD" ] && [ -n "$TL" ]; } || exit 1
cp "$PB" "$OUT/libproot.so"
cp "$LD" "$OUT/libproot-loader.so"
cp "$TL" "$OUT/libtalloc.so"
chmod +x "$OUT"/*.so
echo "[proot] Termux proot установлен"
